"""
CCT 建模优化代码
A16 二维数据可视化 Plot2 示例


作者：赵润晓
日期：2021年5月2日
"""

from os import error, path
import sys
sys.path.append(path.dirname(path.abspath(path.dirname(__file__))))

from cctpy import *

# Plot2 封装了 matplotlib 的一些简单绘图函数

