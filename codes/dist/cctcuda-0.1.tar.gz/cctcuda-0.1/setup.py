import setuptools

setuptools.setup(
    name="cctcuda",
    version="0.1",
    author="zrx",
    author_email="578562554@qq.com",
    description="",
    long_description="cct cuda",
    long_description_content_type="text",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)